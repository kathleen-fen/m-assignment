<template>
    <div class="report">
        <div class="row" >
            <div class="col-md-3" :class="className">Machine:</div>
            <div class="col-md-3" :class="className">{{ machine.MACHINE }}</div>
        </div>
        <div class="row">
            <div class="col-md-3" :class="className">Production:</div>
            <div class="col-md-3" :class="className">{{ machine.PRODUCTION }}</div>
        </div>
        <div class="row">
            <div class="col-md-3" :class="className">Scrap percentage:</div>
            <div class="col-md-3" :class="className">{{ machine.SCRAP_PERCENTAGE }}</div>
        </div>
         <div class="row">
            <div class="col-md-3" :class="className">Downtime percentage:</div>
            <div class="col-md-3" :class="className">{{ machine.DOWNTIME_PERCENTAGE }}</div>
        </div>
        <div class="row">
            <div class="col-md-3" :class="className">Availability:</div>
            <div class="col-md-3" :class="className">{{ ooe.AVAILABILITY }}</div>
        </div>
        <div class="row">
            <div class="col-md-3" :class="className">OEE:</div>
            <div class="col-md-3" :class="className">{{ ooe.OEE }}</div>
        </div>
        <div class="row">
            <div class="col-md-3" :class="className">Performance:</div>
            <div class="col-md-3" :class="className">{{ ooe.PERFORMANCE }}</div>
        </div>
         <div class="row">
            <div class="col-md-3" :class="className">Quality:</div>
            <div class="col-md-3" :class="className">{{ ooe.QUALITY }}</div>
        </div>
        
        <table class="table table-sm table-dark">
        <thead>
            <tr>
            <th v-for="h in this.hours" :key="h.name" scope="col"> {{ h.name }}</th>  
            </tr>
        </thead>
        <tbody>
            <tr>
            <td v-for="v in this.hours" :key="v.name">{{ v.value }}</td>
            </tr>
        </tbody>
        </table>
        <div class="row">
            <div class="col-md-12">
                <Graph
                    :hoursKeys="hoursKeys"
                    :hours="hours"
                 />
            </div>
            
        </div>
        <hr>
        
    </div>
</template>
<script>
import Graph from './Graph'
export default {
    name: 'Report',
    data () {
        return {
            hours: [],
            hoursKeys: [],
            hoursValues: [],
            className: 'good'

        }
    },
    components: {
       Graph
    },
    props: {
        machine: {
            type: Object,
            required:true
        },
        color: {
            type: String,
            required: true
        },
        ooe: {
            type: Object,
            required: true
        }
    },
    created () {
        for (let i=0; i<=23; i++) {
            this.hours.push({
                name: `${i+1}h`,
                value: this.machine[`H${i}`],
                perc: 'p'+ Math.round(this.machine[`H${i}`]/50000*100)
            })
            this.hoursKeys.push(`${i+1}h`)
            this.hoursValues.push(this.machine[`H${i}`])
        }
        if (this.color.includes('warning'))
            this.className = 'warning'
        if (this.color.includes('fatal'))
            this.className = 'fatal' 
        if (this.color.includes('good'))
            this.className = 'good'       
        console.log(this.hours)

        
    }

}
</script>
<style lang="scss" scoped>
.report {
    margin: 20px 0;
}
table {
    margin-top: 10px;
}
.warning {
    background-color: orange;
}
.fatal {
     background-color: red;
}
.good {
     background-color: green;
}
</style>